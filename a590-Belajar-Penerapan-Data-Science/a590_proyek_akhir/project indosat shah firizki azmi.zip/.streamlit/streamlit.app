[paths]
streamlitShareURL = "https://share.streamlit.io"

[client]
toolbarMode = "viewer"
showErrorDetails = true
maxUploadSize = 200

[server]
headless = true
port = 8501
runOnSave = true
raiseServerExceptionsInBrowser = false

[theme]
primaryColor = "#0066cc"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f2f6"
textColor = "#262730"
font = "sans serif"
